; Exemplo.s
; Desenvolvido para a placa EK-TM4C1294XL
; Prof. Guilherme Peron
; 12/03/2018

; -------------------------------------------------------------------------------
        THUMB                        ; Instru��es do tipo Thumb-2
; -------------------------------------------------------------------------------
; Declara��es EQU - Defines
;<NOME>         EQU <VALOR>
; -------------------------------------------------------------------------------
; �rea de Dados - Declara��es de vari�veis
		AREA  DATA, ALIGN=2
		; Se alguma vari�vel for chamada em outro arquivo
		;EXPORT  <var> [DATA,SIZE=<tam>]   ; Permite chamar a vari�vel <var> a 
		                                   ; partir de outro arquivo
;<var>	SPACE <tam>                        ; Declara uma vari�vel de nome <var>
                                           ; de <tam> bytes a partir da primeira 
                                           ; posi��o da RAM		

; -------------------------------------------------------------------------------
; �rea de C�digo - Tudo abaixo da diretiva a seguir ser� armazenado na mem�ria de 
;                  c�digo
        AREA    |.text|, CODE, READONLY, ALIGN=2

		; Se alguma fun��o do arquivo for chamada em outro arquivo	
        EXPORT Start                ; Permite chamar a fun��o Start a partir de 
			                        ; outro arquivo. No caso startup.s
									
		; Se chamar alguma fun��o externa	
        ;IMPORT <func>              ; Permite chamar dentro deste arquivo uma 
									; fun��o <func>

; -------------------------------------------------------------------------------
; Fun��o main()

VETOR EQU 0x20000400 
MEDIA EQU 0x20000500 
MAIOR EQU 0x20000501 
MENOR EQU 0x20000502 
QTDELEMENTOS EQU 0x20000503 
VARIANCIA EQU 0x20000504 
RAIZ_INTEIRA EQU 0x20000506

Start
; Comece o c�digo aqui <======================================================

;v� os valores que n�o s�o 0 e coloca eles na pilha
	LDR R0, =VETOR
loop0
	LDRB R1, [R0]
	CMP R1, #0
	IT NE
	PUSHNE {R1}
	ADD R0,#1
	ADD R2, #1
	CMP R2, #20
	BNE loop0
	
;zera as 20 posi��es da mem�ria RAM
	LDR R0, =VETOR
	MOV R1, #0
	MOV R2, #0
loop1
	STRB R1, [R0]
	ADD R0,#1
	ADD R2, #1
	CMP R2, #20
	BNE loop1
	
;retira da pilha e recoloca na mem�ria RAM
	LDR R0, =VETOR
	LDR R3, =VETOR
loop2
	POP {R4}
	STRB R4, [R0]
	ADD R0,#1
	CMP R13, R3
	BNE loop2
	
;fazendo a m�dia
	LDR R0, =VETOR
loop3
	LDRB R1, [R0]
	CMP R1,#0
	IT EQ
	BEQ sairloop3
	ADD R5, R1
	ADD R10, #1
	ADD R0,#1
	CMP R1, #0
	BNE loop3
	
sairloop3
	UDIV R5, R10
	LDR R1, =MEDIA
	STRB R5, [R1] ; escreve a m�dia na RAM	
	LDR R1, =QTDELEMENTOS
	STRB R10, [R1] ; escreve a quantidade de elementos v�lido na RAM
	
; achando o maior 
	LDR R0, =VETOR
	LDRB R3, [R0]
	MOV R2, #0
loop4
	LDRB R1, [R0]
	CMP R1, R3
	IT HS
	MOVHS R3, R1
	ADD R2, #1
	ADD R0, #1
	CMP R2, R10
	BNE loop4
	
	LDR R1, =MAIOR
	STRB R3, [R1]

;achando o menor
	LDR R0, =VETOR
	LDRB R3, [R0]
	MOV R2, #0
loop5
	LDRB R1, [R0]
	CMP R1, R3
	IT LO
	MOVLO R3, R1
	ADD R2, #1
	ADD R0, #1
	CMP R2, R10
	BNE loop5
	
	LDR R1, =MENOR
	STRB R3, [R1]
	
;calculando a vari�ncia
;PR�-loop6
	LDR R6, =QTDELEMENTOS
	LDRB R10, [R6] ; R10 � A QUANTIDADE DE ELEMNTOS V�LIDOS
	LDR R7, =MEDIA
	LDRB R9, [R7] ; R9 � A MEDIA DOS VALORES
	
	MOV R5,#0 ; R5 � O CONTADOR
	LDR R0, =VETOR
	
LOOP6
	LDRB R1, [R0] ; R1 S�O OS ELEMENTOS DO VETOR
	ADD R5, #1 ; INCREMENTA O CONTADOR
	SUB R2, R9,R1 ; R2  <== M�DIA - VALOR_ATUAL
	MUL R3, R2, R2 ; R3 <== R2*R2
	ADD R4,R4,R3 ; R4 <== R3 + R4 /// VAI ACUMULANDO A VARIANCIA PARCIAL
	ADD R0, #1 ; INCREMENTAO ENDERE�O PARA A PR�XIMA POSI��O DE MEM�RIA
	CMP R5,R10 ;<== R5-R10 quando for igual eu n�o quero continur o loop, pois eu j� contei 15 elementos
	BLO LOOP6
	
;calculando a vari�ncia
	UDIV R4,R4,R10
	LDR R0, =VARIANCIA
	STRH R4, [R0] ; ESCREVE A VARI�NCIA NA MEM�RIA RAM
	
; achando a parte inteira da raiz
; R4 j� t�m a vari�ncia

;pre-loop7
	MOV R0, #1
	
loop7  ;--> ACHANDO A PARTE INTEIRA DA RAIZ
	MUL R1,R0,R0
	ADD R0,#1
	CMP R1,R4
	BLS loop7
	
	;resposta: a parte inteira da raiz �:
	SUB R0,R0,#2 ;/um por causa do ADD depois da multiplica��o (para o pr�ximo) e outro porque passsou do valor que eu queria
	
	LDR R1,=RAIZ_INTEIRA
	STRB R0,[R1]

	NOP
    ALIGN                           ; garante que o fim da se��o est� alinhada 
    END                             ; fim do arquivo
