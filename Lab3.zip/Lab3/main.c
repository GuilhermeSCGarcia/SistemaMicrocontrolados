// main.c
// Desenvolvido para a placa EK-TM4C1294XL
// Verifica o estado das chaves USR_SW1 e USR_SW2, acende os LEDs 1 e 2 caso estejam pressionadas independentemente
// Caso as duas chaves estejam pressionadas ao mesmo tempo pisca os LEDs alternadamente a cada 500ms.
// Prof. Guilherme Peron

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "tm4c1294ncpdt.h"


//Constantes
const int BYTELIDOS = 5;

void PLL_Init(void);
void SysTick_Init(void);
void SysTick_Wait1ms(uint32_t delay);
void SysTick_Wait1us(uint32_t delay);
void GPIO_Init(void);
void Temporizador_Init();
void UART_Init();
void gira_passo_direita(int angulo);
void gira_passo_esquerda(int angulo);

// UART
int receber_dados();
int receber_dados_nao_bloqueante();
void enviar_dados(int mensagen);

// ADC
int converter_ad();
void empacota_string(char mensagem[]);
void mostra_ADC_e_pos();

// Variavel externa
extern int pos_atual;

// Fun��es internas
void selecionarModo();
int calcula_angulo (int passos);
void lerAngulo();
void girarMotorTerminal();
void mostra_pos();

typedef enum estados
{
    ModoIdle,
    ModoPotenciomentro,
    ModoTerminal
} Modos;

//Variaveis Globais

Modos modo = ModoIdle;
Modos ultimoModo;

int tecla = 0;
char anguloEscrito[BYTELIDOS];
int leituraCorreta = 0;
int anguloConvertido;
int contAngulo = 0;

int main(void)
{
	PLL_Init();
	SysTick_Init();
	GPIO_Init();
	Temporizador_Init();
	UART_Init();
		
	while (1)
	{		
		selecionarModo();
		switch (modo)
    {
      case ModoIdle:
				empacota_string("Sistema em IDLE. Esperando comando...\r\n");
				while( tecla != 't' && tecla == 'p')
				{
						tecla = receber_dados();
				}
				if(tecla == 't')
						modo = ModoTerminal;
				else
						modo = ModoPotenciomentro;
				break;

       case ModoPotenciomentro:
					// ligo o timer 0A
          TIMER0_CTL_R |= 0x01;
					mostra_ADC_e_pos();
						
          break;

       case ModoTerminal:
					// desliga o timer 0A
          TIMER0_CTL_R = 0x00;
					//Le o angulo digitado pelo usu�rio
					lerAngulo();
			    //Gira o motor conforme o angulo digitado
			    girarMotorTerminal();
					//Mostra no terminal
					mostra_pos();
						
          break;
   }
	}
	
}


void empacota_string(char mensagem[])
{
	for(int i = 0; mensagem[i] != '\0'; i++)
	{
		enviar_dados(mensagem[i]);
	}
}

void selecionarModo()
{
	tecla = receber_dados_nao_bloqueante();
	if(tecla)
		{
			switch(tecla)
			{
				case 't':
					modo = ModoTerminal;
					break;
				case 'p':
					modo = ModoPotenciomentro;
					break;
			}
		}
}

int calcula_angulo (int passos)
{
	return ((passos * 360) / 4096);
}

void mostra_ADC_e_pos()
{
	char string[50];
	float adc = pos_atual;
	float pos = calcula_angulo(pos_atual);
						
	// coloca em string o que est� entre aspas
	sprintf(string, "[POT] ADC: %.2f | Posicao: %.2f", adc, pos);
	// manda pro terminal a string
	empacota_string(string);
	empacota_string("\r\n");
}

void mostra_pos()
{
	char string[50];
	float pos = calcula_angulo(pos_atual);
	// coloca em string o que est� entre aspas
	sprintf(string, "[TERM]Posicao: %.2f", pos);
	// manda pro terminal a string
	empacota_string(string);
	empacota_string("\r\n");
}

void lerAngulo()
	{
		empacota_string("Digite o seu angulo\r\n");
		while(!leituraCorreta)//espera o usu�rio digitar um angulo corretamente 
			{
				//Mostra o angulo digitado pelo usu�rio
				for(int i = 0; i < 3; i++)
				{                
					anguloEscrito[i] = receber_dados();
					anguloEscrito[i+1] = '\0';
					empacota_string("Angulo Digitado: ");
					empacota_string(anguloEscrito);
					empacota_string("\r");
				}
				
				//Converte o angulo de char para int
				anguloConvertido = atoi(anguloEscrito + 1);
				//verifica se o angulo digitado foi feito de maneira certa
				if(anguloEscrito[0] != '+' && anguloEscrito[0] != '-')
				{
					empacota_string("+ ou - n�o encontrado\r\n");
				}else if (anguloConvertido < 0 || anguloConvertido > 360)
				{
					empacota_string("angulo fora do valor correto\r\n");
				}else
				{
					leituraCorreta = 1;
				}
			}
		
	}
	
	
//Fiz essa fun��o porque n�o sabia de que modo eu atualizava o terminal.
//void lerAnguloDigitado()
//	{
//		int tecla = receber_dados_nao_bloqueante();
//		if(tecla)
//			{
//				if(contAngulo < 4)
//				{
//				anguloEscrito[contAngulo] = (char)tecla;
//				contAngulo++;
//				}
//					
//				if(contAngulo == 4)
//				{
//					anguloEscrito[contAngulo] = '\0';
//					anguloConvertido = atoi(anguloEscrito + 1);
//					
//					if(anguloEscrito[0] != '+' && anguloEscrito[0] != '-')
//					{
//						empacota_string("+ ou - n�o encontrado\r\n");
//						contAngulo = 0;
//					}else if (anguloConvertido < 0 || anguloConvertido > 360)
//					{
//						empacota_string("angulo fora do valor correto\r\n");
//						contAngulo = 0;
//					}else
//					{
//						contAngulo = 0;
//						girarMotorTerminal();
//					}
//				}
//			}
//	}
	
	//m�todo para girar o motor em modo terminal
	void girarMotorTerminal()
	{
					if(anguloEscrito[0] == '+')
					{
						gira_passo_direita(anguloConvertido);
					}else if (anguloEscrito[0] == '-')
					{
						gira_passo_esquerda(anguloConvertido);
					}else
					{
						return;
					}		
	}
	
	
	
